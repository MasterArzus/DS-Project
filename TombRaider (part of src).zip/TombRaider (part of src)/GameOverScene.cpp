#include "StartScene.h"
#include "GameOverScene.h"

GameOverScene::GameOverScene()
{
	// ����ͼƬ
	auto background = gcnew Sprite("gameover.png");
	this->addChild(background);
}

void GameOverScene::onUpdate()
{
	if (Input::isDown(KeyCode::Enter))
	{
		SceneManager::enter(gcnew StartScene(false));
	}
}

#include"Mom.h"

Mom::Mom(Settings settings)//ľ����
	:Enemy(settings)
{
	//mom�ĳ�ʼͼ
	this->open("stone1.png");

}

void Mom::Attack(Raider& raider)
{
	//�������˼���
	float scale = 2.5;
	float limit = 180.0;
	if (sqrt(pow(this->getPosX() - raider.getPosX(),2) + pow(this->getPosY() - raider.getPosY(),2)) < limit)//ŷ����þ���
	{
		//std::cout << "attack!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;
		this->setSpeed(setting.enemy_attack_speed);
		
	}
	else
	{
		this->setSpeed(setting.enemy_speed);
	}
	
}

void Mom::Tracing(Raider& raider, Room& r)
{
	if (this->getLiving())//�������
	{
		Enemy::Tracing(raider, r);
		Attack(raider);
	}
	else
	{


	}

}
		



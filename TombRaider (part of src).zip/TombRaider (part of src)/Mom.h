#pragma once
#include "Settings.h"
#include"Raider.h"
#include"Room.h"
#include"Enemy.h"
#include<iostream>
//ľ����
class Mom :public Enemy
{
public:
	Mom(Settings settings);

	virtual void Attack(Raider& raider) override;

	virtual void Tracing(Raider& raider, Room& r) override;
private:



};
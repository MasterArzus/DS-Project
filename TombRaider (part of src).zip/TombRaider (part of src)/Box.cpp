#include "Box.h"

Box::Box(Settings settings)
{
	setting = settings;

	this->open("box.png");
	this->setScale(setting.box_scale);
}

void Box::onUpdate()
{
	if (is_open) {
		this->open("boxopen.png");
	}
}

bool Box::getIsOpen()
{
	return is_open;
}

void Box::setIsOpen(bool value)
{
	is_open = value;
}


#pragma once
#include "Settings.h"

class Player {
public:
	Player(int i,String n,int s,int** m,int c);

	void setID(int value);
	int getID();

	void setName(String value);
	String getName();

	void setScore(int value);
	int getScore();

	void setMap(int** value);
	int** getMap();

	void setCount(int value);
	int getCount();

private:
	int ID;
	String name;
	int score;
	int** map;
	int count;	//��ͼ��room����
};
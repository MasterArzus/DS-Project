#include "Stone.h"

Stone::Stone()
{
	//���ѡȡһ��ͼ��Ϊʯͷ����ͼ
	int type = Random::range(1, 3);
	if (type == 1) {
		this->open("stone1.png");
	}
	else if (type == 2)
	{
		this->open("stone2.png");
	}
	else if (type == 3) {
		this->open("stone3.png");
	}
}

#include "RangeScene.h"

RangeScene::RangeScene(bool active)
{
	auto background = gcnew Sprite("pause.png");
	this->addChild(background);

	Title = gcnew Info("Rank");
	Title->setPos(Window::getWidth() / 2, 100);
	this->addChild(Title);


	// ȷ�ϰ�ť
	OKBtn = gcnew MyTextButton("OK", [=]() {
		this->Exit();
		});
	OKBtn->setPos(Window::getWidth() / 2, 480);
	OKBtn->setFillColor(0xFFFFFF);
	this->addChild(OKBtn);

}

void RangeScene::showRange(std::vector<int>& vec)
{
	int num = 6;
	for (int i = 0; i < num; i++)
	{
		auto rank = gcnew Info(std::to_string(i) + "     "+ std::to_string(vec[i]) + "     " + std::to_string(vec[i]));
		Title->setPos(Window::getWidth() / 2, 100 + (i + 1) * 50);
		this->addChild(Title);
	}

}



void RangeScene::Exit()
{
	SceneManager::back();
}

void RangeScene::onUpdate()
{
	if (Input::isPress(KeyCode::Esc)) {

		SceneManager::back();

	}
}

Info::Info(const String& text)
{
	this->setText(text);
	this->setFont(Font("΢���ź�", 28, Font::Weight::Bold));
	this->setFillColor(0xFFFFFF);
}

void Info::changeText(const String& text)
{
	this->setText(text);
	this->setFont(Font("΢���ź�", 28, Font::Weight::Bold));
	this->setFillColor(0xFFFFFF);
}

#pragma once
#include "Settings.h"

class Block : public Sprite
{
public:
	Settings setting;
	Block(Settings settings);

	//�Զ���λ
	void AutoPos(String type, Block* origin);

private:

};
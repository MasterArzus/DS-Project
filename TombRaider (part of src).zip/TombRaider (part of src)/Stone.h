#pragma once
#include "Settings.h"

class Stone : public Sprite
{
public:
	Stone();

private:

};
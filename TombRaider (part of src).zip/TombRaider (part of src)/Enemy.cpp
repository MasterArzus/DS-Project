#include"Enemy.h"

bool Enemy::getLiving()
{
	return living;
}

void Enemy::setLiving(bool value)
{
	living = false;
}

int Enemy::getBlood()
{
	return HP;
}

void Enemy::setBlood(int value)
{
	HP = value;
}

float Enemy::getSpeed()
{
    return speed;
}


void Enemy::setSpeed(float speed)
{
    this->speed = speed;
}

int Enemy::getCellSize()
{
    return cell_size;
}

Enemy::Enemy(Settings settings)
	:living(true), attack(2)
{
	setting = settings;
	HP = 0.5 * setting.raider_init_blood;
	speed = setting.enemy_speed;
	
	for (int i = 0; i < grid_size_x + 1; ++i) {
		std::vector<int> row(grid_size_y, 0);
		map.push_back(row);
	}
}


// �ĸ�����
int dx[4] = { 1, 0, -1, 0 };
int dy[4] = { 0, 1, 0, -1 };


// �Ƚ�����cell��fֵ
bool cmp(Enemy::Cell a, Enemy::Cell b) {
    return a.f > b.f;
}

// ����hֵ(�����پ���)
int calH(Enemy::Cell cur, Enemy::Cell end) {
    return abs(cur.x - end.x) + abs(cur.y - end.y);
}

// A*Ѱ·
std::vector<std::pair<int, int>> Enemy::astar(Enemy::Cell& start, Enemy::Cell& end, Room& r) {
    //����·��
    std::vector<std::pair<int, int>> path;
    // openlist��closelist
    std::priority_queue<Enemy::Cell, std::vector<Enemy::Cell>, bool(*)(Enemy::Cell, Enemy::Cell)> open(cmp);
    std::vector<int> close((grid_size_x+1) * grid_size_y, 0);
    Stone** stone_array = r.getStoneArray();

    //��ʯͷ��������Ϊ1������ͨ��
    for (int i = 0; i < r.getStoneNumber(); i++)
    {
        int stone_cell_x = setting.getGrid(stone_array[i]->getPosX());
        int stone_cell_y = setting.getGrid(stone_array[i]->getPosY());
        //std::cout << "getPosX:" << stone_array[i]->getPosX() << ",getPosY��" << stone_array[i]->getPosY() << std::endl;

        map[stone_cell_x][stone_cell_y] = 1;
        //std::cout << "map(" << stone_cell_x << "," << stone_cell_y << ") = " << map[stone_cell_x][stone_cell_y] << std::endl;
    }

    // ��������openlist
    start.g = 0;
    start.h = calH(start, end);
    start.f = start.g + start.h;
    open.push(start);

    // A*����
    while (!open.empty()) {
        // ȡfֵ��С��cell
        Enemy::Cell* cur = new Enemy::Cell(open.top());
        open.pop();

        // ����ҵ��յ��˾ͷ��ؽ��
        if (cur->x == end.x && cur->y == end.y) {
            Enemy::Cell* c = cur;
            while (c!=nullptr) {
                path.push_back({ c->x, c->y });
                c = c->parent; // ��close list��ȡ���ڵ�
            }
            return path;
        }

        // �����close�б�,����
        if (close[cur->x * (grid_size_y) + cur->y] == 1) continue;
        else close[cur->x * (grid_size_y) + cur->y] = 1;

        // �ĸ�������
        for (int i = 0; i < 4; i++) {
            Enemy::Cell next;
            next.x = cur->x + dx[i];
            next.y = cur->y + dy[i];

            // ���û����,û��close list,Ҳ����ǽ
            if (next.x >= 0 && next.x < grid_size_x+1
                && next.y >= 0 && next.y < grid_size_y
                && map[next.x][next.y] == 0 &&
                close[next.x * (grid_size_y) + next.y] != 1) {
                next.g = cur->g + 1;
                next.h = calH(next, end);
                next.f = next.g + next.h;
                next.parent = cur;
                open.push(next);
            }
        }
    }
}

void Enemy::MoveTo(Vector2& v)
{
     this->setPos(v);
}

/*
void Enemy::Tracing(Raider& raider, Room& r)
{
	float x = this->getPosX();
	float y = this->getPosY();
	float _x = raider.getPosX();
	float _y = raider.getPosY();
	Vector2 dir(_x - x, _y - y);
	normalize(dir);
	Vector2 l(dir.x * this->getSpeed() + this->getPos().x, dir.y * this->getSpeed() + this->getPos().y);
	this->MoveTo(l);
}
*/


void Enemy::Tracing(Raider& raider, Room& room)
{
	//================enemy move=======================
	//������ʱ��
	current = clock();
	delta = current - last;

	//�������λ����Ŀ��λ��
	Enemy::Cell start;//����λ��
	float x_pos_enemy = this->getPosX();//��ͼ����
	float y_pos_enemy = this->getPosY();
	int x_cell_enemy = setting.getGrid(x_pos_enemy);//��������
	int y_cell_enemy = setting.getGrid(y_pos_enemy);
	start.x = x_cell_enemy;
	start.y = y_cell_enemy;
	//std::cout << "x_cell_enemy:" << x_cell_enemy << " " << "y_cell_enemy:" << y_cell_enemy << std::endl;

	//std::cout << "x_pos_enemy:" << x_pos_enemy << " " << "y_pos_enemy:" << y_pos_enemy << std::endl;
	//std::cout << "x_pos_raider:" << x_pos_raider << " " << "y_pos_raider:" << y_pos_raider << std::endl;

	current_center_x_coord = x_cell_enemy * setting.stone_width + setting.stone_width / 2 + setting.border_length;
	current_center_y_coord = y_cell_enemy * setting.stone_width + setting.stone_width / 2 + setting.border_length;

	if (!ifinit)
	{
		path = this->astar(start, end, room);
		ifinit = true;
	}

	int n = path.size();

	//std::cout << "n: " << n << std::endl;
	//std::cout << "end.x:" << end.x << " " << "end.y:" << end.y << std::endl;
	//std::cout << "start.x:" << start.x << " " << "start.y:" << start.y << std::endl;

	for (auto i : path)
	{
		//std::cout << "(" << i.first << "," << i.second << ")";
	}

//	std::cout << std::endl;
	if (n < 2)//��ͬһ��������
	{
		direction = Vector2(end.x - start.x, end.y - start.y);
		normalize(direction);
	}
	else if (n >= 2)//·��������������������
	{
		int next_center_x = (*(path.end() - 2)).first;//��һ���������ĵ�
		int next_center_y = (*(path.end() - 2)).second;
		next_center_x_coord = next_center_x * setting.stone_width + setting.stone_width / 2 + setting.border_length;
		next_center_y_coord = next_center_y * setting.stone_width + setting.stone_width / 2 + setting.border_length;

		if (!is_on_track)
		{
			//std::cout << "+++++++++++++++++++++++++++++++++++++++++++++++++++++++correct++++++++++++++++++++++++++++++++++++++++++++++++" << std::endl;
			//��ǰ�������굽�������ĵ�����ķ�������
			Vector2 cur2cell = Vector2(current_center_x_coord - x_pos_enemy, current_center_y_coord - y_pos_enemy);
			normalize(cur2cell);
			//·��ǰ�����򣺵�ǰ�������ĵ���һ���������ķ�������
			Vector2 cur2next = Vector2(next_center_x - x_cell_enemy, next_center_y - y_cell_enemy);//һ���Ǳ�׼�ģ����ù�һ��
			float cos_theta = cur2cell.x * cur2next.x + cur2cell.y * cur2next.y;
			//std::cout << "cur2cell:(" << cur2cell.x << "," << cur2cell.y << ")" << std::endl;
			//std::cout << "cur2next:(" << cur2next.x << "," << cur2next.y << ")" << std::endl;
			//std::cout << "cos_theta:" << cos_theta << std::endl;
			if (cos_theta >= 0)
			{
				//����ǰ�������ĵ���
				direction = cur2cell;
				des = Vector2(current_center_x_coord, current_center_y_coord);
			}
			else
			{
				//����һ�����ĵ���
				direction = cur2next;
				des = Vector2(next_center_x_coord, next_center_y_coord);
			}
			//std::cout << "des:(" << des.x << "," << des.y << ")" << std::endl;

		}
		//std::cout << "abs(des.x - x_pos_enemy):" << abs(des.x - x_pos_enemy) << " "
			//<< "abs(des.y - y_pos_enemy):" << abs(des.y - y_pos_enemy) << std::endl;
		if (is_on_track == false && abs(des.x - x_pos_enemy) <= 1 && abs(des.y - y_pos_enemy) <= 1)//�ߵ���Ŀ�ĵ�
		{
			is_on_track = true;//�������
		}

		if (is_on_track)
		{
			if (to_change_dir == true)
			{
				//std::cout << "�ı��˷���" << std::endl;

				direction = Vector2(next_center_x - x_cell_enemy, next_center_y - y_cell_enemy);
				to_change_dir = false;
			}

			//std::cout << "current_center_x: " << x_cell_enemy << " current_center_y: " << y_cell_enemy << std::endl;
			//std::cout << "next_center_x: " << next_center_x << " next_center_y: " << next_center_y << std::endl;
			//std::cout << "dir_x: " << direction.x << " dir_y: " << direction.y << std::endl;


			//����߹���������񣬰������path��ɾ��
			//std::cout << "next_center_x_coord:" << next_center_x_coord << " " << "next_center_y_coord:" << next_center_y_coord << std::endl;
			//std::cout << "abs(x_pos_enemy - next_center_x_coord):" << abs(x_pos_enemy - next_center_x_coord) << " "
				//<< "abs(y_pos_enemy - next_center_y_coord):" << abs(y_pos_enemy - next_center_y_coord) << std::endl;

			if (abs(x_pos_enemy - next_center_x_coord) <= 2*this->getSpeed() && abs(y_pos_enemy - next_center_y_coord) <= 2 * this->getSpeed())
			{
				//std::cout << "===================================================================================delete=================================================================: " << (*(path.end() - 2)).first << " " << (*(path.end() - 2)).second << std::endl;

				path.erase(path.end() - 2);//ɾ������
				//��·���������������ĳɵ�ǰ����
				//std::cout << "before:     path.back().first: " << path.back().first << " path.back().second: " << path.back().second << std::endl;

				path.back().first = x_cell_enemy;
				path.back().second = y_cell_enemy;

				//std::cout << "after:     path.back().first: " << path.back().first << " path.back().second: " << path.back().second << std::endl;

				to_change_dir = true;

			}
		}

	}

	Vector2 pos = Vector2(direction.x * this->getSpeed() + x_pos_enemy, direction.y * this->getSpeed() + y_pos_enemy);
	this->MoveTo(pos);

//	std::cout << std::endl;
	if (delta >= 2000.0)
	{
		//std::cout << "-------------------------------------------------------------------------------------------------------------------------------" << std::endl;
		x_pos_raider = raider.getPosX();//��ͼ����
		y_pos_raider = raider.getPosY();
		x_cell_raider = setting.getGrid(x_pos_raider); //��������
		y_cell_raider = setting.getGrid(y_pos_raider);
		end.x = x_cell_raider;
		end.y = y_cell_raider;
		to_change_dir = true;
		is_on_track = false;

		path.clear();
		auto newVec = this->astar(start, end, room);
		path.insert(path.end(), newVec.begin(), newVec.end());
		//std::cout << "start: " << start.x << " " << start.y << " end:" << end.x << " " << end.y << std::endl;

		delta = 0;
		last = current;

	}

}





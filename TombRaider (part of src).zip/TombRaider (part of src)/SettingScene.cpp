#include "SettingScene.h"

SettingScene::SettingScene(bool active)
{
	auto background = gcnew Sprite("pause.png");
	this->addChild(background);

	roomNum = gcnew Info("ROOM NUMBER: ");
	roomNum->setPos(Window::getWidth() / 2 - 400, 200);
	this->addChild(roomNum);

	Num = gcnew Info(" ");
	// ���ط�����
	Num->changeText("");
	Num->setPos(Window::getWidth() / 2 - 200, 200);
	this->addChild(Num);

	// ���ڷ���������ť
	plusBtn = gcnew MyTextButton("UP", [=]() {
		this->roomUP();
		});
	plusBtn->setPos(Window::getWidth() / 2, 200);
	plusBtn->setFillColor(0xFFFFFF);
	this->addChild(plusBtn);


	minusBtn = gcnew MyTextButton("DOWN", [=]() {
		this->roomDown();
		});
	minusBtn->setPos(Window::getWidth() / 2 + 100, 200);
	minusBtn->setFillColor(0xFFFFFF);
	this->addChild(minusBtn);

	// �ѶȰ�ť
	Diff = gcnew Info("DIFFICULTY: ");
	Diff->setPos(Window::getWidth() / 2 - 400, 350);
	this->addChild(Diff);

	easyBtn = gcnew MyTextButton("EASY", [=]() {
		this->ToEasy();
		});
	easyBtn->setPos(Window::getWidth() / 2, 350);
	easyBtn->setFillColor(0xFFFFFF);
	this->addChild(easyBtn);


	normalBtn = gcnew MyTextButton("NORMAL", [=]() {
		this->ToNormal();
		});
	normalBtn->setPos(Window::getWidth() / 2 + 120, 350);
	normalBtn->setFillColor(0xFFFFFF);
	this->addChild(normalBtn);


	hardBtn = gcnew MyTextButton("HARD", [=]() {
		this->ToHard();
		});
	hardBtn->setPos(Window::getWidth() / 2 + 300, 350);
	hardBtn->setFillColor(0xFFFFFF);
	this->addChild(hardBtn);

	// ȷ�ϰ�ť
	OKBtn = gcnew MyTextButton("OK", [=]() {
		this->Exit();
		});
	OKBtn->setPos(Window::getWidth() / 2, 480);
	OKBtn->setFillColor(0xFFFFFF);
	this->addChild(OKBtn);

}

void SettingScene::roomUP()
{
	// ���ط�����
	Num->changeText("");
}

void SettingScene::roomDown()
{
	// ���ط�����
	Num->changeText("");
}

void SettingScene::ToEasy()
{

}

void SettingScene::ToNormal()
{

}

void SettingScene::ToHard()
{

}

void SettingScene::Exit()
{
	SceneManager::back();
}

void SettingScene::onUpdate()
{
	if (Input::isPress(KeyCode::Esc)) {

		SceneManager::back();

	}
}

Info::Info(const String& text)
{
	this->setText(text);
	this->setFont(Font("΢���ź�", 28, Font::Weight::Bold));
	this->setFillColor(0xFFFFFF);
}

void Info::changeText(const String& text)
{
	this->setText(text);
	this->setFont(Font("΢���ź�", 28, Font::Weight::Bold));
	this->setFillColor(0xFFFFFF);
}

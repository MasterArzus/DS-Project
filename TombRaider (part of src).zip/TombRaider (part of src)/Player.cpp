#include "Player.h"

Player::Player(int i, String n, int s, int** m, int c)
{
	ID = i;
	name = n;
	score = s;
	count = c;
	
	map = new int* [4];
	for (int i = 0; i < 4; i++) {
		map[i] = new int[count];
	}

	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < count; j++) {
			map[i][j] = m[i][j];
		}
	}
}

void Player::setID(int value)
{
	ID = value;
}

int Player::getID()
{
	return ID;
}

void Player::setName(String value)
{
	name = value;
}

String Player::getName()
{
	return name;
}

void Player::setScore(int value)
{
	score = value;
}

int Player::getScore()
{
	return score;
}

void Player::setMap(int** value)
{
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < count; j++) {
			map[i][j] = value[i][j];
		}
	}
}

int** Player::getMap()
{
	return map;
}

void Player::setCount(int value)
{
	count = value;
}

int Player::getCount()
{
	return count;
}

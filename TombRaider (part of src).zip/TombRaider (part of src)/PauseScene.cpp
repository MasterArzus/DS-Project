#include "PauseScene.h"

PauseScene::PauseScene(int* pass, int current_room, int count, int** map,Settings settings)
{
	setting = settings;

	// ���ӱ���ͼ
	auto background = gcnew Sprite("pause.png");
	this->addChild(background);

	
	// ������Ϸ��ť
	resumeBtn = gcnew MyTextButton("Continue", [=]() {
		this->Continue();
		});

	resumeBtn->setAnchor(0.5, 0.5);
	// ���ð�ťλ��
	resumeBtn->setPos(Window::getWidth() / 2, 490);
//	this->addChild(resumeBtn);

	//����С��ͼ
	minimap = new Minimap(setting.default_map_count, map, pass,setting);
	//��ʼ��С��ͼ
	for (int i = 0; i < setting.default_map_count; i++) {
		auto block = minimap->getBlock(i);
		this->addChild(block, 3);
		printf("%d", i);
	}

	minimap->setCurrentRoom(current_room);

	updateMinimap();
}

void PauseScene::Continue()
{
	SceneManager::back();
}

void PauseScene::onUpdate()
{
//	minimap->showMinimap();
	if (Input::isPress(KeyCode::M)) {

		SceneManager::back();

	}
}

void PauseScene::passBlock(int index)
{
//	minimap->passBlock(index);
}

void PauseScene::updateMinimap()
{
	minimap->showMinimap();
}

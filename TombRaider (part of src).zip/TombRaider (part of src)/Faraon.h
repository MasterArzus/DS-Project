#pragma once
#include "Settings.h"
#include"Raider.h"
#include"Room.h"
#include"Enemy.h"
#include<iostream>
//����
class Faraon :public Enemy
{
public:
	Faraon(Settings settings);

	virtual void Attack(Raider& raider) override;

	virtual void Tracing(Raider& raider, Room& r) override;

	// ���ϵ��ӵ�
	std::vector<Bullet*> bullets;
	int Bulletcounter;
private:



};
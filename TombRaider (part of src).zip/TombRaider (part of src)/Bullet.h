#pragma once
#include <easy2d/easy2d.h>

using namespace easy2d;

#define M_PI 3.141592653f

class Bullet : public Sprite
{
public:
	float degree;
	float speed = 300;
	int damage = 1;
	bool activated = false;
	Bullet();
	void set_activated(bool);
	void move();
	void stop();
};

#pragma once
#include <easy2d/easy2d.h>

using namespace easy2d;

class GameOverScene : public Scene
{
public:
	GameOverScene();
	void onUpdate() override;
};


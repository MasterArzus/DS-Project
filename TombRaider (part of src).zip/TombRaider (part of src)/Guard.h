#pragma once
#include "Settings.h"
#include"Raider.h"
#include"Room.h"
#include"Enemy.h"
#include<iostream>
//����
class Guard :public Enemy
{
public:
	Guard(Settings settings);

	virtual void Attack(Raider& raider) override;

	virtual void Tracing(Raider& raider, Room& r) override;

	void Patrol(Enemy::Cell& start);
private:
	int go = 1;


};
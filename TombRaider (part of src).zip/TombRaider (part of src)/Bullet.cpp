#include <corecrt_math.h>
#include "Bullet.h"
#include<iostream>
Bullet::Bullet() : Sprite("bullet.png")
{
	this->activated = false;
	this->setAnchor(0.5f, 0.5f);
	this->setPos(0, 0);
	this->degree =  -M_PI / 2;
}

void Bullet::set_activated(bool a)
{
	this->activated = a;
}

void Bullet::stop()
{
	this->setPos(1200, 1200);
	this->activated = false;
	this->setVisible(false);
}

void Bullet::move()
{
	//std::cout << this->activated << std::endl;

	if (this->activated)
	{
		
		float distance = speed * Time::getDeltaTime();
		this->setPosX(getPosX() + distance * cos(degree));
		this->setPosY(getPosY() + distance * sin(degree));
		if ((this->getPosY() >= Window::getHeight() - 6) || this->getPosY() < 6)
		{
			//degree = -degree;
			this->stop();
		}
		if ((this->getPosX() <= 6) || this->getPosX() >= Window::getWidth() - 6)
		{
			//degree = M_PI - degree;
			this->stop();
		}
	}
}

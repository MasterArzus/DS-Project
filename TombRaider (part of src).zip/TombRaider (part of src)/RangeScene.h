#pragma once
#include "Buttons.h"
#include "RangeScene.h"
#include"Settings.h"

class Info : public Text
{
public:
	Info(const String& text);

	void changeText(const String& text);

private:
	bool enabled = true;
};

class RangeScene : public Scene
{
public:
	Settings setting;

	RangeScene(bool active);

	void showRange(std::vector<int>& vec);

	void Exit();

	void onUpdate();


protected:

	// ȷ�ϰ�ť
	MyTextButton* OKBtn;
	
	// Notice
	//Sprite* Background = gcnew Sprite("Notice.png");

	Info* Title;

	bool is_active = 0;

};



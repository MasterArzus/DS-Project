#pragma once
#include "Buttons.h"
#include "GameScene.h"
#include"Settings.h"

class Info : public Text
{
public:
	Info(const String& text);

	void changeText(const String& text);

private:
	bool enabled = true;
};

class SettingScene : public Scene
{
public:
	Settings setting;

	SettingScene(bool active);

	// ������������
	void roomUP();
	// ���������½�
	void roomDown();
	// easy mode
	void ToEasy();
	// normal mode
	void ToNormal();
	// hard mode
	void ToHard();
	// OK
	void Exit();

	void onUpdate();


protected:
	// ���ڷ���������ť
	MyTextButton* plusBtn;
	MyTextButton* minusBtn;

	// �ѶȰ�ť
	MyTextButton* easyBtn;
	MyTextButton* normalBtn;
	MyTextButton* hardBtn;

	// ȷ�ϰ�ť
	MyTextButton* OKBtn;
	
	// Notice
	//Sprite* Background = gcnew Sprite("Notice.png");

	Info* roomNum;
	Info* Num;
	Info* Diff;

	bool is_active = 0;

};



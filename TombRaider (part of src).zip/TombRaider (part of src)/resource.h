//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� TombRaider.rc ʹ��
//
#define IDI_ICON1                       101
#define IDB_PNG1                        102
#define IDB_PNG2                        103
#define IDB_PNG3                        104
#define IDB_PNG4                        105
#define IDB_PNG5                        106
#define IDB_PNG6                        107
#define IDB_PNG7                        108
#define IDB_PNG8                        109
#define IDB_PNG9                        110
#define IDB_PNG10                       111
#define IDB_PNG11                       112
#define IDB_PNG12                       113
#define IDB_PNG13                       114
#define IDB_PNG14                       115
#define IDB_PNG15                       116
#define IDB_PNG16                       117
#define IDB_PNG17                       118
#define IDB_PNG18                       119
#define IDB_PNG19                       120
#define IDB_PNG20                       121
#define IDB_PNG21                       122
#define IDB_PNG22                       123
#define IDB_PNG23                       124
#define IDB_PNG24                       125
#define IDB_PNG25                       126
#define IDB_PNG26                       127
#define IDB_PNG27                       128
#define IDB_PNG28                       129
#define IDB_PNG29                       130
#define IDB_PNG30                       131
#define IDB_PNG31                       132
#define IDB_PNG32                       133
#define IDB_PNG33                       134
#define IDB_PNG34                       135
#define IDB_PNG35                       136
#define IDB_PNG36                       137
#define IDB_PNG37                       138
#define IDB_PNG38                       139
#define IDB_PNG39                       140
#define IDB_PNG40                       141
#define IDR_ACCELERATOR1                142
#define IDB_PNG41                       143
#define IDB_PNG42                       144
#define IDB_PNG43                       145
#define IDB_PNG44                       146
#define IDB_PNG45                       147
#define IDB_PNG46                       148
#define IDB_PNG47                       149
#define IDB_PNG48                       150
#define IDB_PNG49                       151
#define IDB_PNG50                       152

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

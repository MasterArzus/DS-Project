#pragma once
#include "Buttons.h"
#include "Minimap.h"
#include "Settings.h"

class PauseScene : public Scene
{
public:
	Settings setting;
	PauseScene(int* pass, int current_room, int count, int** map,Settings settings);
	// ������Ϸ
	void Continue();

	void onUpdate();

	void passBlock(int index);

	//ˢ��С��ͼ
	void updateMinimap();
private:
	// ������Ϸ��ť
	MyTextButton* resumeBtn;


	Minimap* minimap;

};
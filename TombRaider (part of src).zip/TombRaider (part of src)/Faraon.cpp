#include "Faraon.h"

Faraon::Faraon(Settings settings)//����
	:Enemy(settings)
{
	//faraon�ĳ�ʼͼ
	this->open("stone3.png");
}

//���ù��﹥��ʱ����
float cur, la, del;

void Faraon::Attack(Raider& raider)
{
	cur = clock();
	del = cur - la;
	if (del > 2000)
	{
		la = cur;
		del = 0;

		bullets[Bulletcounter]->set_activated(true);
		bullets[Bulletcounter]->setVisible(true);
		bullets[Bulletcounter]->setPos(this->getPosX(), this->getPosY());

		float x = raider.getPosX() - this->getPosX();
		float y = raider.getPosY() - this->getPosY();

		bullets[Bulletcounter]->degree = atan2(y, x);

		Bulletcounter--;
		if (Bulletcounter < 0) Bulletcounter = bullets.size() - 1;
		if (Bulletcounter > bullets.size() - 1) Bulletcounter = 0;

	}

}

void Faraon::Tracing(Raider& raider, Room& r)
{
	if (this->getLiving())//�������
	{
		Enemy::Tracing(raider, r);
		Attack(raider);
	}
	else
	{

	}
}

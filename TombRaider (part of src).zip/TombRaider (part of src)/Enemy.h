#pragma once
#include "Settings.h"
#include"Raider.h"
#include"Room.h"
#include <vector>
#include <queue>
#include<iostream>


class Enemy :public Sprite
{
public:
	
	Settings setting;

	std::vector<std::vector<int>> map;
	// �����ͼ
	const int HEIGHT = setting.HEIGHT - 2 * setting.border_length;
	const int WIDTH = setting.WIDTH - 2 * setting.border_length;
	const int cell_size = setting.stone_width;
	const int grid_size_x = WIDTH / cell_size;
	const int grid_size_y = HEIGHT / cell_size;

	// �ṹ���ʾһ������
	struct Cell {
		int x;
		int y;
		int f; // f=g+h 
		int g; // �����ľ���
		int h; // ���յ�Ĺ��ƾ��� 
		Cell* parent = nullptr;
	};

	Enemy(Settings setting);

	//��ȡ������living״̬
	bool getLiving();
	void setLiving(bool value);

	//��ȡ������blood
	int getBlood();
	void setBlood(int value);

	//��ȡ������speed
	float getSpeed();
	void setSpeed(float speed);

	//��ȡcell_size
	int getCellSize();

	//A* ׷������
	std::vector<std::pair<int, int>> astar(Enemy::Cell& start, Enemy::Cell& end, Room& r);

	void MoveTo(Vector2&);


	//��һ��
	void normalize(Vector2& v)
	{
		float m = sqrt(v.x * v.x + v.y * v.y);
		if (m == 0)
		{
			v.x = 0;
			v.y = 0;
		}
		else
		{
			v.x = v.x / m;
			v.y = v.y / m;
		}
	}

	virtual void Tracing(Raider& raider, Room& r);

	virtual void Attack(Raider& raider) = 0;
	

private:
	//==============================��Ա==============================
	bool living;//�Ƿ���
	float HP;//Ѫ��
	float speed;//�ٶ�
	float attack;//������
	
	float current;
	float last;
	float delta;
	float x_pos_raider;
	float y_pos_raider;
	float current_center_x_coord;
	float current_center_y_coord;
	float next_center_x_coord;
	float next_center_y_coord;

	bool ifinit = false;
	bool is_on_track = false;
	bool to_change_dir = true;
	std::vector<std::pair<int, int>> path;
	Enemy::Cell end;
	Vector2 direction;
	Vector2 des;

	int x_cell_raider;
	int y_cell_raider;

};